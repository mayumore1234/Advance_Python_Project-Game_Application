from django.contrib import admin

from django.urls import path

from gamedetails import views

from .settings import DEBUG,STATIC_URL,MEDIA_URL,STATIC_ROOT,MEDIA_ROOT

from django.conf.urls.static import static


urlpatterns = [

    path('admin/', admin.site.urls),

    path('',views.index),

]

if DEBUG:
    urlpatterns+=static(STATIC_URL,document_root=STATIC_ROOT)
    urlpatterns+=static(MEDIA_URL,document_root=MEDIA_ROOT)