from django.db import models
# Create your models here.

class Game(models.Model):

    name=models.CharField(max_length=255)

    picture=models.ImageField()

    type=models.CharField(max_length=200)

    noofplayer=models.IntegerField()

    description=models.TextField()

    def __str__(self):

        result=self.name +" is a  "+self.type

        return result



    class Meta:

        db_table='game'