from django.apps import AppConfig


class GamedetailsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'gamedetails'
