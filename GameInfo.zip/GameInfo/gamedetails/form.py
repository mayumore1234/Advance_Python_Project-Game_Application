from django import forms

#import model class from models.py

#from app_name.models import model_name

from gamedetails.models import Game



class GameForm(forms.ModelForm):

    class Meta:

        model=Game

        fields="__all__"